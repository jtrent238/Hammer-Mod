--
-- Sounds
--

--function hammermod.toasterbreak(table)
--	table = table or {}
--	table.toasterbreak = table.toasterbreak or
--			{name = "toasterbreak", gain = 1.0}
--	return table
--end

--function hammermod.toasterbake(table)
--	table = table or {}
--	table.toasterbake = table.toasterbake or
--			{name = "toasterbake", gain = 1.0}
--	return table
--end

--function hammermod.smash(table)
--	table = table or {}
--	table.smash = table.smash or
--			{name = "smash", gain = 1.0}
--	return table
--end
