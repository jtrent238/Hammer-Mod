
  if minetest.get_player_name() == "jtrent238" then
      minetest.log(info, "It seems you have a custom hammer in the mod, lets get it for you. (NOTE: This is a test)")
	  else minetest.log(info, "You do not have a custom hammer in the mod, this is still work in progress.")
end