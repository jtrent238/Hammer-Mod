# jtrent238's Hammer Mod - MineTest Edition [WIP]

This version is for the game [MineTest](https://minetest.net).

* Please note that this version of my HammerMod MineTest Edition is very much *_Work In Progress_* and it is not up to date with the Minecraft version.

## Download Latest version of HammerMod MineTest:
* [Download PreRelease](https://github.com/jtrent238/Hammer-Mod/raw/master/MineTest/hammermod/MineTest.zip)

![img1](https://puu.sh/zhBuk/b73ca48bac.png)
![img2](https://puu.sh/zhBuD/f29d3cba59.png)
![img3](https://puu.sh/zhBuv/b503a3ca77.png)
![img4](https://puu.sh/zhBuB/8aa69b28ba.png)
![img5](https://puu.sh/zhBuZ/de631e3b7c.png)